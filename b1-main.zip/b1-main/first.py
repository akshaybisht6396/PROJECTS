a =1
b =1.2
c ="str"
d ="str2"
e = True 
f = 1+2j



print(a)
print(b)
print(c)
print(d)
print(e)
print(f)